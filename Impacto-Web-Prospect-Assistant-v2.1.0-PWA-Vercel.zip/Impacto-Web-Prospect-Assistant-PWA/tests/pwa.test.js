import test from 'node:test';
import assert from 'node:assert/strict';
import { access, readFile, stat } from 'node:fs/promises';
import { join } from 'node:path';

const root = process.cwd();

test('manifesto PWA possui instalacao completa e icones validos', async () => {
  const manifest = JSON.parse(await readFile(join(root, 'app.webmanifest'), 'utf8'));
  assert.equal(manifest.display, 'standalone');
  assert.equal(manifest.start_url, '/?source=pwa');
  assert.equal(manifest.scope, '/');
  assert.ok(manifest.icons.some(icon => icon.sizes === '192x192'));
  assert.ok(manifest.icons.some(icon => icon.sizes === '512x512'));
  for (const icon of manifest.icons) {
    const path = join(root, icon.src.replace(/^\//, ''));
    await access(path);
    assert.ok((await stat(path)).size > 1000);
  }
});

test('service worker armazena apenas arquivos locais existentes', async () => {
  const source = await readFile(join(root, 'service-worker.js'), 'utf8');
  const list = source.match(/const CORE_ASSETS = \[([\s\S]*?)\];/)?.[1] || '';
  const assets = Array.from(list.matchAll(/'([^']+)'/g), match => match[1]);
  assert.ok(assets.length >= 15);
  for (const asset of assets) await access(join(root, asset.replace(/^\//, '')));
  assert.match(source, /request\.mode === 'navigate'/);
  assert.match(source, /caches\.match\('\/dashboard\.html'\)/);
});

test('Vercel entrega a dashboard na raiz e nao armazena service worker antigo', async () => {
  const config = JSON.parse(await readFile(join(root, 'vercel.json'), 'utf8'));
  assert.deepEqual(config.rewrites[0], { source: '/', destination: '/dashboard.html' });
  const workerHeaders = config.headers.find(item => item.source === '/service-worker.js')?.headers || [];
  assert.ok(workerHeaders.some(header => header.key === 'Cache-Control' && /max-age=0/.test(header.value)));
});

test('dashboard declara manifesto, instalacao e modo web seguro', async () => {
  const html = await readFile(join(root, 'dashboard.html'), 'utf8');
  const js = await readFile(join(root, 'dashboard.js'), 'utf8');
  assert.match(html, /rel="manifest" href="app\.webmanifest"/);
  assert.match(html, /id="btnInstallApp"/);
  assert.match(html, /id="runtimeNotice"/);
  assert.match(js, /hasExtensionAutomation/);
  assert.match(js, /Importar base de seguidores/);
});
