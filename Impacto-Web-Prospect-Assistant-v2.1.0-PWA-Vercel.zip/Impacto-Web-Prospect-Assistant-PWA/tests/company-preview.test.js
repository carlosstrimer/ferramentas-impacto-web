import test from 'node:test';
import assert from 'node:assert/strict';
import '../company-preview.js';
import { parseCSVText } from '../modules/importer.js';
import { parseInstagramPage, createLeadFromInstagram } from '../modules/instagram-analyzer.js';

test('prévia preserva imagens e vídeos importados', () => {
  const [lead] = parseCSVText('Empresa;Email;Instagram;Imagens;Vídeos\nLoja Azul;loja@gmail.com;@lojaazul;https://example.com/foto.jpg;https://example.com/video.mp4');
  const data = globalThis.CompanyPreview.describe(lead);
  assert.equal(data.email, 'loja@gmail.com');
  assert.equal(data.instagram, 'https://www.instagram.com/lojaazul/');
  assert.deepEqual(data.images, ['https://example.com/foto.jpg']);
  assert.deepEqual(data.videos, ['https://example.com/video.mp4']);
});

test('análise profunda leva mídia visível e e-mail público para o lead', () => {
  const profile = parseInstagramPage({ title: 'Loja Azul (@lojaazul) • Instagram', headerText: 'Loja Azul\nloja@gmail.com', mediaImages: ['https://example.com/post.jpg'], mediaVideos: ['https://www.instagram.com/reel/abc/'] }, '@lojaazul');
  const lead = createLeadFromInstagram(profile);
  assert.equal(lead.email, 'loja@gmail.com');
  assert.deepEqual(lead.mediaImages, ['https://example.com/post.jpg']);
  assert.deepEqual(lead.mediaVideos, ['https://www.instagram.com/reel/abc/']);
});
