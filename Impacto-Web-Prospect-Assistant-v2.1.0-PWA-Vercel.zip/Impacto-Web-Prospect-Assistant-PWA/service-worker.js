const CACHE_NAME = 'iw-prospect-v2.1.0-pwa-1';
const CORE_ASSETS = [
  '/dashboard.html',
  '/dashboard.css',
  '/dashboard.js',
  '/company-preview.css',
  '/company-preview.js',
  '/pwa.js',
  '/app.webmanifest',
  '/assets/impacto-web-logo.svg',
  '/assets/impacto-web-icon-48.png',
  '/assets/impacto-web-icon-192.png',
  '/assets/impacto-web-icon-512.png',
  '/modules/csv-parser.js',
  '/modules/db.js',
  '/modules/exporter.js',
  '/modules/importer.js',
  '/modules/instagram-analyzer.js',
  '/modules/lead-scoring.js',
  '/modules/message-generator.js',
  '/modules/phone.js',
  '/modules/utils.js'
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(CORE_ASSETS)));
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;

  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request).catch(() => caches.match('/dashboard.html'))
    );
    return;
  }

  event.respondWith(
    caches.match(request).then(cached => {
      if (cached) return cached;
      return fetch(request).then(response => {
        if (!response || response.status !== 200 || response.type !== 'basic') return response;
        const copy = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(request, copy));
        return response;
      });
    })
  );
});
