const isWebRuntime = ['http:', 'https:'].includes(location.protocol);
const isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);
const isAndroid = /android/i.test(navigator.userAgent);

const installButtons = [
  document.getElementById('btnInstallApp'),
  document.getElementById('btnInstallAppSettings')
].filter(Boolean);
const installCard = document.getElementById('pwaInstallCard');
const backdrop = document.getElementById('installBackdrop');
const dialog = document.getElementById('installDialog');
const instructions = document.getElementById('installInstructions');
const closeButton = document.getElementById('btnCloseInstall');

let deferredPrompt = null;
let lastFocus = null;

function setInstallVisibility(visible) {
  installButtons.forEach(button => { button.hidden = !visible; });
  if (installCard) installCard.hidden = !visible;
}

function installationCopy() {
  if (isIOS) {
    return `
      <p>Use o Safari para instalar:</p>
      <ol>
        <li>Toque no botao <strong>Compartilhar</strong>.</li>
        <li>Escolha <strong>Adicionar a Tela de Inicio</strong>.</li>
        <li>Confirme em <strong>Adicionar</strong>.</li>
      </ol>
      <p class="install-note">O app abre em tela cheia e mantem os dados salvos neste dispositivo.</p>
    `;
  }
  if (isAndroid) {
    return `
      <p>No Chrome ou Edge para Android:</p>
      <ol>
        <li>Abra o menu do navegador.</li>
        <li>Toque em <strong>Instalar app</strong> ou <strong>Adicionar a tela inicial</strong>.</li>
        <li>Confirme a instalacao.</li>
      </ol>
      <p class="install-note">Se a opcao nao aparecer, atualize a pagina e tente novamente.</p>
    `;
  }
  return `
    <p>Abra o menu do navegador e escolha <strong>Instalar Impacto Web Prospect Assistant</strong>.</p>
    <ol>
      <li>No Chrome ou Edge, procure o icone de instalacao na barra de endereco.</li>
      <li>Confirme para criar o atalho em modo aplicativo.</li>
    </ol>
    <p class="install-note">No celular, abra este mesmo endereco pelo Chrome ou Safari.</p>
  `;
}

function openInstallHelp() {
  if (!backdrop || !instructions) return;
  lastFocus = document.activeElement;
  instructions.innerHTML = installationCopy();
  backdrop.hidden = false;
  dialog?.focus?.();
  closeButton?.focus();
}

function closeInstallHelp() {
  if (!backdrop) return;
  backdrop.hidden = true;
  lastFocus?.focus?.();
}

async function requestInstall() {
  if (!deferredPrompt) {
    openInstallHelp();
    return;
  }
  deferredPrompt.prompt();
  const choice = await deferredPrompt.userChoice;
  deferredPrompt = null;
  if (choice.outcome === 'accepted') setInstallVisibility(false);
}

if (!isWebRuntime || isStandalone) {
  setInstallVisibility(false);
} else {
  setInstallVisibility(true);
  installButtons.forEach(button => button.addEventListener('click', requestInstall));
}

window.addEventListener('beforeinstallprompt', event => {
  event.preventDefault();
  deferredPrompt = event;
  if (!isStandalone) setInstallVisibility(true);
});

window.addEventListener('appinstalled', () => {
  deferredPrompt = null;
  setInstallVisibility(false);
  closeInstallHelp();
});

closeButton?.addEventListener('click', closeInstallHelp);
backdrop?.addEventListener('click', event => {
  if (event.target === backdrop) closeInstallHelp();
});
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && backdrop && !backdrop.hidden) closeInstallHelp();
});

if (isWebRuntime && 'serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/service-worker.js', { scope: '/' }).catch(error => {
      console.warn('Service worker indisponivel:', error);
    });
  });
}

window.__IW_PWA__ = { openInstallHelp, closeInstallHelp, isStandalone };
