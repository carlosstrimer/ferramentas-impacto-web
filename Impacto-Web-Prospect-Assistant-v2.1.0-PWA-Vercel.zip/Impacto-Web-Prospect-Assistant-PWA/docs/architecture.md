# Arquitetura 2.0

## Fluxo

1. O usuario informa uma conta-semente, por exemplo `@renato_cariani`.
2. A extensao abre o perfil em segundo plano usando a sessao normal do navegador.
3. Um script isolado abre a lista de seguidores e coleta somente os perfis visiveis no DOM, com limite de 10 mil.
4. A triagem leve salva todos os candidatos em lotes de 100, sem carregar avatares e sem abrir cada perfil.
5. A selecao profunda combina sinais comerciais, extremos e distribuicao ao longo da lista.
6. Cada seguidor selecionado e aberto individualmente, sempre em uma unica aba temporaria.
7. A analise profunda e salva em lotes de 10 e pode ser pausada ou cancelada.
8. O motor local calcula score de 1 a 5, dor, oportunidade e abordagem.
9. Apenas os seguidores entram no funil. A conta-semente fica registrada como origem.

## Estrategia de memoria

- No maximo uma aba de perfil e aberta por vez.
- A lista de triagem omite URLs de avatar, reduzindo o volume serializado.
- Leads de triagem sao persistidos em lotes de 100.
- Perfis aprofundados sao persistidos em lotes de 10.
- A dashboard renderiza 40 linhas por pagina.
- Atualizacoes completas da interface acontecem por marcos, nao a cada seguidor.

## Limites tecnicos

- O Instagram pode exigir login, alterar o DOM, virtualizar a lista ou limitar consultas.
- A extensao nao promete ler todos os seguidores de contas grandes.
- Os limites de coleta e analise sao configuraveis para reduzir bloqueios.
- Dez mil e um teto tecnico de tentativa, nao garantia de que o Instagram exibira toda a lista.
- Aprofundar milhares de perfis pode levar horas e acionar limites da plataforma.
- Nenhum endpoint privado, token de sessao ou credencial e lido ou armazenado.

## Permissoes

- `storage`: configuracoes locais.
- `tabs`: abrir e fechar perfis em segundo plano.
- `scripting`: executar os coletores nas paginas do Instagram.
- Host: somente `https://www.instagram.com/*`.

