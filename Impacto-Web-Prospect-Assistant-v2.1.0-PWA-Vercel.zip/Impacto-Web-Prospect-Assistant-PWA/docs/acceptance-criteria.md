# Criterios de Aceite

- [x] A conta-semente nao e adicionada como lead.
- [x] Seguidores duplicados sao removidos da amostra.
- [x] A amostra e distribuida ao longo da lista coletada.
- [x] A triagem aceita configuracao de ate 10 mil seguidores.
- [x] Perfis de triagem e analise profunda ficam identificados separadamente.
- [x] O processamento profundo usa apenas uma aba por vez.
- [x] A persistencia incremental usa lotes pequenos e preserva resultados parciais.
- [x] A prospeccao pode ser pausada ou cancelada entre perfis.
- [x] A logo oficial da Impacto Web aparece na dashboard, popup e icone da extensao.
- [x] Todos os botoes da dashboard e do popup possuem smoke test.
- [x] Cada seguidor analisado recebe score de 1 a 5.
- [x] A origem `@semente` fica vinculada ao seguidor.
- [x] A dashboard exibe maior e menor potencial separadamente.
- [x] Perfis privados continuam usando os sinais publicos disponiveis.
- [x] Login e bloqueios do Instagram geram mensagens claras.
- [x] A extensao nao envia DMs nem automatiza autenticacao.
- [ ] Coleta real de seguidores validada em sessao autenticada do Instagram.

