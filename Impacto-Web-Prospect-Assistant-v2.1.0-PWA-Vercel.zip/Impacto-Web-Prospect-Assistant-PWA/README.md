# Impacto Web Prospect Assistant 2.1 + PWA

Projeto hibrido com extensao Chromium Manifest V3 e aplicativo web instalavel. A extensao encontra potenciais clientes dentro da audiencia de perfis famosos; a PWA permite importar, qualificar, organizar e abordar os leads no celular, inclusive offline.

## Principais recursos

- Triagem economica de ate 10 mil seguidores visiveis de uma conta-semente.
- Salvamento incremental em lotes de 100 registros para reduzir uso de memoria.
- Analise aprofundada configuravel, processada em uma unica aba temporaria por vez.
- Pausa e cancelamento com preservacao dos dados ja salvos.
- Priorizacao de sinais comerciais, extremos e amostra distribuida; a conta famosa nao vira lead.
- Qualificacao explicavel de 1 a 5.
- Identificacao de dor, oportunidade e proximo passo.
- Nove estrategias de mensagem, incluindo dor especifica, consultiva, oportunidade, autoridade, follow-up e reativacao.
- Tres variacoes de mensagem por lead.
- Importacao CSV/JSON e exportacao CSV/JSON.
- Funil comercial, observacoes e follow-up.
- Previa da empresa no painel do lead, com Instagram, e-mail, imagens e links de videos disponiveis; permite completar URLs e baixar HTML.
- Persistencia local em IndexedDB.
- Backup e restauracao completos.
- PWA instalavel no Android, iPhone e computador.
- Cache offline dos arquivos essenciais e deploy estatico na Vercel.

## Instalacao da extensao desktop

1. Extraia o arquivo ZIP.
2. Abra `chrome://extensions`, `edge://extensions` ou `brave://extensions`.
3. Ative o modo desenvolvedor.
4. Clique em **Carregar sem compactacao**.
5. Selecione a pasta extraida.
6. Abra a extensao e clique em **Abrir dashboard completa**.

## Publicacao na Vercel

1. Envie esta pasta para um repositorio GitHub.
2. Na Vercel, clique em **Add New > Project** e importe o repositorio.
3. Mantenha **Framework Preset** como `Other` e nao defina comando de build.
4. Mantenha o diretorio de saida vazio e publique.

O arquivo `vercel.json` entrega `dashboard.html` na raiz, configura o manifesto e impede cache antigo do service worker. Nenhuma variavel de ambiente e necessaria.

## Instalacao no celular

- Android: abra a URL publicada no Chrome ou Edge, toque em **Instalar app** e confirme.
- iPhone/iPad: abra no Safari, toque em **Compartilhar > Adicionar a Tela de Inicio**.
- Computador: use o icone de instalacao na barra de endereco do Chrome ou Edge.

No app instalado, importacao CSV/JSON, qualificacao, funil, mensagens, exportacao e backup funcionam localmente. A coleta automatica de seguidores pelo `@` exige APIs de extensao (`chrome.tabs` e `chrome.scripting`) e, por isso, permanece exclusiva da extensao desktop. O app movel informa essa diferenca e direciona para a importacao sem prometer uma coleta indisponivel no navegador do celular.

## Mineracao de audiencia no Instagram

A extensao solicita acesso apenas a `https://www.instagram.com/*`. Informe o `@` de um famoso, influenciador ou perfil de referencia. A extensao abre a lista de seguidores visivel e pode fazer triagem local de ate 10 mil perfis. Em seguida, aprofunda somente a quantidade escolhida, um perfil por vez.

O fluxo recomendado para computadores com ate 16 GB de RAM e:

1. selecionar a quantidade total para triagem;
2. aprofundar uma parcela menor, por exemplo 50 de 500 ou 100 de 10 mil;
3. filtrar por nota e por nivel de analise antes da abordagem;
4. aumentar a profundidade em uma nova execucao apenas quando necessario.

Os perfis de triagem recebem menor confianca e ficam identificados como **Triagem leve**. Perfis visitados individualmente ficam identificados como **Analise profunda**.

Na analise profunda, a previa pode usar o avatar, miniaturas e links de Reels que estiverem visiveis no perfil no momento da coleta, alem de e-mail publico encontrado na bio. A disponibilidade depende da pagina e do login. O recurso nao acessa Gmail nem videos privados; um link de Reel abre no Instagram. Imagens e videos tambem podem vir por CSV/JSON ou ser adicionados manualmente no painel do lead. O botao **Baixar HTML** gera uma previa compartilhavel com os dados presentes.

A conta-semente serve apenas como origem. Ela nao e adicionada ao funil.

O Instagram normalmente exige que o usuario esteja conectado no navegador para abrir a lista de seguidores. A extensao nao automatiza login, nao usa endpoints privados e nao contorna bloqueios. A quantidade coletada pode variar por carregamento, privacidade e limites da plataforma. Coletas grandes podem levar varios minutos; aprofundar milhares de perfis pode levar horas e sofrer limitacao da plataforma.

A dashboard e responsiva e pode ser instalada como PWA. O Chrome padrao do Android nao permite instalar extensoes; por isso, o app movel trabalha com bases importadas enquanto a coleta por audiencia e feita no computador.

O score considera:

- necessidade digital;
- tracao e prova social;
- facilidade de contato;
- aderencia aos servicos da Impacto Web;
- maturidade da operacao digital atual.

O modelo nao garante fechamento. Ele organiza prioridades comerciais com base nos dados disponiveis.

## Privacidade

- Sem servidor proprio.
- Sem API externa de IA.
- Sem envio automatico de mensagens.
- Leads, mensagens e configuracoes permanecem no navegador.

## Desenvolvimento

```bash
npm test
npm run check
npm run smoke
npm run layout
npm run dev
```

Os testes cobrem qualificacao, escala de 10 mil, processamento economico, leitura de dados do Instagram, geracao de mensagens, importacao, exportacao segura de CSV, botoes da dashboard/popup, responsividade, manifesto PWA, cache offline e configuracao da Vercel.
