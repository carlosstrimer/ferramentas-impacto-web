import { spawn } from 'node:child_process';
import { mkdir, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

const chromePath = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const appPort = 4700 + (process.pid % 200);
const debugPort = 9400 + (process.pid % 200);
const profilePath = join(process.cwd(), `.tmp-layout-check-${process.pid}`);
const targetUrl = `http://127.0.0.1:${appPort}/dashboard.html`;
const widths = [360, 390, 430, 768, 820, 1024, 1280, 1440, 1920];
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));

const server = spawn(process.execPath, ['scripts/dev-server.mjs'], {
  cwd: process.cwd(),
  env: { ...process.env, PORT: String(appPort) },
  stdio: 'ignore',
  windowsHide: true
});
let chrome = null;

async function waitForServer() {
  for (let attempt = 0; attempt < 40; attempt++) {
    try {
      const response = await fetch(targetUrl);
      if (response.ok) return;
    } catch (_) {}
    await wait(250);
  }
  throw new Error('O servidor local nao ficou disponivel.');
}

async function getPage() {
  for (let attempt = 0; attempt < 40; attempt++) {
    try {
      const pages = await fetch(`http://127.0.0.1:${debugPort}/json/list`).then(response => response.json());
      const page = pages.find(item => item.type === 'page');
      if (page) return page;
    } catch (_) {}
    await wait(250);
  }
  throw new Error('Chrome DevTools nao ficou disponivel.');
}

class CdpClient {
  constructor(url) {
    this.socket = new WebSocket(url);
    this.nextId = 1;
    this.pending = new Map();
    this.socket.onmessage = event => {
      const message = JSON.parse(event.data);
      if (!message.id || !this.pending.has(message.id)) return;
      const { resolve, reject } = this.pending.get(message.id);
      this.pending.delete(message.id);
      if (message.error) reject(new Error(message.error.message));
      else resolve(message.result);
    };
  }

  async ready() {
    if (this.socket.readyState === WebSocket.OPEN) return;
    await new Promise((resolve, reject) => {
      this.socket.onopen = resolve;
      this.socket.onerror = reject;
    });
  }

  call(method, params = {}) {
    const id = this.nextId++;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.socket.send(JSON.stringify({ id, method, params }));
    });
  }

  close() {
    this.socket.close();
  }
}

async function setViewport(cdp, width, height, url = targetUrl) {
  await cdp.call('Emulation.setDeviceMetricsOverride', {
    width,
    height,
    deviceScaleFactor: 1,
    mobile: width <= 430
  });
  const separator = url.includes('?') ? '&' : '?';
  await cdp.call('Page.navigate', { url: `${url}${separator}width=${width}` });
  await wait(url.includes('dashboard.html') ? 1200 : 700);
}

async function saveScreenshot(cdp, width, height, filename, url = targetUrl) {
  await setViewport(cdp, width, height, url);
  const screenshot = await cdp.call('Page.captureScreenshot', {
    format: 'png',
    fromSurface: true,
    captureBeyondViewport: false
  });
  await mkdir(join(process.cwd(), 'artifacts'), { recursive: true });
  await writeFile(join(process.cwd(), 'artifacts', filename), Buffer.from(screenshot.data, 'base64'));
}

try {
  await waitForServer();
  chrome = spawn(chromePath, [
    '--headless=new',
    '--disable-gpu',
    '--hide-scrollbars',
    `--remote-debugging-port=${debugPort}`,
    `--user-data-dir=${profilePath}`,
    targetUrl
  ], { stdio: 'ignore', windowsHide: true });

  const page = await getPage();
  const cdp = new CdpClient(page.webSocketDebuggerUrl);
  await cdp.ready();
  await cdp.call('Page.enable');
  await cdp.call('Runtime.enable');

  const results = [];
  for (const width of widths) {
    await setViewport(cdp, width, width <= 430 ? 844 : 1000);
    const evaluation = await cdp.call('Runtime.evaluate', {
      returnByValue: true,
      expression: `(() => {
        const root = document.documentElement;
        const offenders = Array.from(document.querySelectorAll('body *'))
          .filter(element => !element.closest('.table-wrap'))
          .map(element => ({
            tag: element.tagName,
            id: element.id || '',
            className: typeof element.className === 'string' ? element.className : '',
            right: Math.round(element.getBoundingClientRect().right),
            width: Math.round(element.getBoundingClientRect().width)
          }))
          .filter(item => item.right > root.clientWidth + 1 || item.width > root.clientWidth + 1)
          .slice(0, 8);
        return {
          title: document.title,
          clientWidth: root.clientWidth,
          scrollWidth: root.scrollWidth,
          overflow: root.scrollWidth > root.clientWidth,
          offenders
        };
      })()`
    });
    results.push({ requestedWidth: width, ...evaluation.result.value });
  }

  await saveScreenshot(cdp, 1440, 1100, 'dashboard-scale-desktop.png');
  await saveScreenshot(cdp, 390, 900, 'dashboard-scale-mobile.png');
  const popupUrl = `http://127.0.0.1:${appPort}/popup.html`;
  await saveScreenshot(cdp, 360, 620, 'popup-scale.png', popupUrl);
  const popupEvaluation = await cdp.call('Runtime.evaluate', {
    returnByValue: true,
    expression: `({
      title: document.title,
      clientWidth: document.documentElement.clientWidth,
      scrollWidth: document.documentElement.scrollWidth,
      overflow: document.documentElement.scrollWidth > document.documentElement.clientWidth
    })`
  });
  results.push({ surface: 'popup', requestedWidth: 360, ...popupEvaluation.result.value });
  cdp.close();
  console.log(JSON.stringify(results, null, 2));
  if (results.some(result => result.overflow || !result.title.startsWith('Impacto Web Prospect Assistant'))) {
    process.exitCode = 1;
  }
} finally {
  if (chrome) chrome.kill();
  server.kill();
}
