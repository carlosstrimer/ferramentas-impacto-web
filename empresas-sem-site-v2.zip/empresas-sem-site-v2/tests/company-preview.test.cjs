const { test } = require("node:test");
const assert = require("node:assert/strict");
const preview = require("../company-preview.js");
const core = require("../core.js");

test("prévia usa somente mídias e contatos fornecidos", () => {
  const lead = core.normalizeLead({ source: "Google Maps", sourceId: "1", nome: "Loja Azul", email: "loja@gmail.com", instagram: "@lojaazul", mediaImages: ["https://example.com/foto.jpg", "javascript:alert(1)"], mediaVideos: ["https://www.instagram.com/reel/abc/", "file:///segredo.mp4"] });
  const data = preview.describe(lead);
  assert.equal(data.email, "loja@gmail.com");
  assert.equal(data.instagram, "https://www.instagram.com/lojaazul");
  assert.deepEqual(data.images, ["https://example.com/foto.jpg"]);
  assert.deepEqual(data.videos, ["https://www.instagram.com/reel/abc/"]);
});

test("importação e exportação preservam imagens e vídeos do lead", () => {
  const row = core.mapImportedRow({ Empresa: "Loja Azul", Imagens: "https://example.com/a.jpg | https://example.com/b.jpg", Vídeos: "https://example.com/video.mp4" });
  const lead = core.normalizeLead(row);
  assert.equal(lead.mediaImages.length, 2);
  assert.equal(lead.mediaVideos.length, 1);
  assert.match(core.exportCsv([lead]), /https:\/\/example\.com\/video\.mp4/);
});
