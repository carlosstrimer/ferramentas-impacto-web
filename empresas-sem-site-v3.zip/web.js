(function (root) {
  "use strict";
  const sessionKey = "empresasSemSiteTeamSession", localKey = "empresasSemSiteLocalV3";
  let config = null, session = null, onState = () => {}, poller = null;
  const $ = id => document.getElementById(id);
  const showLogin = message => { $("webLogin").hidden = false; $("webLoginMessage").textContent = message || "Entre com a conta cadastrada pela equipe."; };
  const hideLogin = () => { $("webLogin").hidden = true; $("webPassword").value = ""; };
  const readLocal = () => { try { return { leads: [], logs: [], run: null, ...(JSON.parse(localStorage.getItem(localKey) || "{}")) }; } catch { return { leads: [], logs: [], run: null }; } };
  const saveLocal = state => { localStorage.setItem(localKey, JSON.stringify(state)); onState(state); return state; };
  const logLocal = (state, message) => { state.logs = [...(state.logs || []), `${new Date().toLocaleString("pt-BR")} ${message}`].slice(-100); };
  function mergeLocal(state, raw) {
    const incoming = LeadCore.normalizeLead(raw);
    if (!incoming.nome || !incoming.sourceId) return 0;
    const index = state.leads.findIndex(lead => LeadCore.sameLead(lead, incoming));
    if (index < 0) { incoming.history.push({ at: Date.now(), by: "Este navegador", action: `Captado em ${incoming.source}` }); state.leads.push(incoming); return 1; }
    state.leads[index] = LeadCore.mergeLead(state.leads[index], incoming);
    state.leads[index].history = [...(state.leads[index].history || []), { at: Date.now(), by: "Este navegador", action: `Atualizado por ${incoming.source}` }].slice(-50);
    return 0;
  }
  async function localAction(type, payload) {
    const state = readLocal();
    if (type === "START_MAPS") throw new Error("Google Maps requer a integração Google Places e a base da equipe. Use OpenStreetMap ou a extensão instalada.");
    if (type === "START_OSM") {
      try {
        const result = await json(await fetch("/api/public-search", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload.payload || {}), cache: "no-store" }));
        let added = 0, matched = 0;
        for (const row of result.rows || []) {
          const count = mergeLocal(state, row); added += count;
          if (count && ["SEM_SITE_CONFIRMADO", "SO_WHATSAPP", "SO_REDES", "SITE_QUEBRADO"].includes(LeadCore.normalizeLead(row).reason)) matched++;
        }
        state.run = { source: "OpenStreetMap", status: "done", found: result.found, scanned: result.scanned, added, matched, message: "Pesquisa concluída.", finishedAt: Date.now() };
        logLocal(state, `OpenStreetMap: ${payload.payload.keyword} em ${payload.payload.city}. ${result.found} encontrados, ${result.scanned} analisados, ${added} novos, ${matched} oportunidades.`);
        saveLocal(state); return { ok: true, state, added, found: result.found };
      } catch (error) {
        state.run = { source: "OpenStreetMap", status: "error", found: 0, scanned: 0, added: 0, matched: 0, message: error.message, finishedAt: Date.now() };
        logLocal(state, `OpenStreetMap: ${error.message}`); saveLocal(state); throw error;
      }
    }
    if (type === "IMPORT_LEADS" || type === "IMPORT_BACKUP") {
      const backup = type === "IMPORT_BACKUP" ? payload.data : null;
      const rows = backup ? backup.leads : payload.rows;
      if (!Array.isArray(rows) || rows.length > (backup ? 10000 : 100)) throw new Error("Arquivo inválido ou grande demais.");
      let added = 0;
      for (const row of rows) added += mergeLocal(state, { ...row, source: backup ? row.source : payload.source });
      if (backup?.messageSettings) state.messageSettings = backup.messageSettings;
      if (backup?.messageTemplates) state.messageTemplates = backup.messageTemplates;
      logLocal(state, `${rows.length} registros importados, ${added} novos.`);
      saveLocal(state); return { ok: true, state, added };
    }
    if (type === "UPDATE_LEAD") {
      const lead = state.leads.find(item => item.id === payload.id);
      if (!lead) throw new Error("Lead não encontrado.");
      const changed = [];
      if (LeadCore.STAGES.includes(payload.stage)) { lead.stage = payload.stage; changed.push("etapa"); }
      if (LeadCore.REASONS.includes(payload.reason)) { lead.reason = payload.reason; lead.reasonManual = true; changed.push("qualificação"); }
      for (const key of ["notes", "email", "instagram", "messageText", "messageStatus", "followUpDate", "previewUrl", "ownerId"]) if (typeof payload[key] === "string") { lead[key] = payload[key].trim(); changed.push(key); }
      for (const key of ["mediaImages", "mediaVideos"]) if (Array.isArray(payload[key])) {
        lead[key] = LeadCore.mediaUrls(payload[key]); changed.push(key);
        lead.mediaAttribution = { ...(lead.mediaAttribution || {}), ...Object.fromEntries(lead[key].filter(url => !lead.mediaAttribution?.[url]).map(url => [url, { label: "Equipe", sourceUrl: "" }])) };
      }
      lead.score = LeadCore.score(lead); lead.updatedAt = Date.now();
      if (changed.length) lead.history = [...(lead.history || []), { at: Date.now(), by: "Este navegador", action: `Alterou ${changed.join(", ")}` }].slice(-50);
      saveLocal(state); return { ok: true, state };
    }
    if (type === "UPDATE_MESSAGE_SETTINGS") { state.messageSettings = payload.settings; state.messageTemplates = payload.templates; logLocal(state, "Modelos e configurações atualizados."); saveLocal(state); return { ok: true, state }; }
    if (type === "CLEAR_LOG") { state.logs = []; saveLocal(state); return { ok: true, state }; }
    if (type === "LOOKUP_EMPRESAQUI") throw new Error("Consulta EmpresAqui requer a base da equipe. Importe um CSV/JSON ou use a extensão instalada.");
    throw new Error("Ação indisponível no modo local.");
  }
  async function json(response) {
    const data = await response.json().catch(() => ({}));
    if (!response.ok || data.ok === false) throw Object.assign(new Error(data.error || `Serviço indisponível (HTTP ${response.status}).`), { status: response.status });
    return data;
  }
  async function auth(grant, values) {
    const response = await fetch(`${config.supabaseUrl.replace(/\/$/, "")}/auth/v1/token?grant_type=${grant}`, {
      method: "POST", headers: { apikey: config.anonKey, "Content-Type": "application/json" }, body: JSON.stringify(values), cache: "no-store"
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || !data.access_token) throw new Error(data.msg || data.error_description || "Não foi possível entrar. Confira e-mail e senha.");
    session = { accessToken: data.access_token, refreshToken: data.refresh_token, expiresAt: Date.now() + (Number(data.expires_in) || 3600) * 1000 };
    sessionStorage.setItem(sessionKey, JSON.stringify(session));
  }
  async function refreshToken() {
    if (!session?.refreshToken) throw new Error("Sessão expirada. Entre novamente.");
    await auth("refresh_token", { refresh_token: session.refreshToken });
  }
  async function request(path, options = {}, retry = true) {
    if (!session?.accessToken) throw new Error("Entre com sua conta da equipe.");
    if (session.expiresAt < Date.now() + 30000) await refreshToken();
    const response = await fetch(path, { ...options, headers: { Authorization: `Bearer ${session.accessToken}`, ...(options.body ? { "Content-Type": "application/json" } : {}), ...(options.headers || {}) }, cache: "no-store" });
    if (response.status === 401 && retry) { await refreshToken(); return request(path, options, false); }
    return json(response);
  }
  async function sync() {
    if (api.localMode) { const state = readLocal(); onState(state); return { ok: true, state }; }
    const result = await request("/api/state");
    api.members = result.members || []; api.actor = result.actor || null;
    onState(result.state || { leads: [], logs: [], run: null });
    hideLogin();
    return result;
  }
  async function login(event) {
    event.preventDefault();
    const button = $("webLoginButton"); button.disabled = true; $("webLoginMessage").textContent = "Entrando...";
    try {
      await auth("password", { email: $("webEmail").value.trim(), password: $("webPassword").value });
      await sync();
    } catch (error) { session = null; sessionStorage.removeItem(sessionKey); showLogin(error.message); }
    finally { button.disabled = false; $("webPassword").value = ""; }
  }
  async function init(callback) {
    onState = callback;
    document.body.classList.add("web-mode");
    $("webLoginForm").addEventListener("submit", login);
    $("webLogout").addEventListener("click", () => { session = null; sessionStorage.removeItem(sessionKey); api.actor = null; api.members = []; showLogin("Sessão encerrada."); });
    try {
      config = await json(await fetch("/api/config", { cache: "no-store" }));
      api.googleAvailable = Boolean(config.googleAvailable);
      if (!config.configured) {
        api.localMode = true; api.actor = { name: "Este navegador" }; hideLogin(); $("webLogout").hidden = true;
        $("osmLimit").max = "20"; $("osmRadius").max = "5000";
        document.querySelector(".side-note").textContent = "Modo local: os dados ficam neste navegador. Para compartilhar com a equipe, configure o banco no Vercel.";
        document.querySelector("#tab-settings .page-heading p:last-child").textContent = "Modo local: os dados ficam neste navegador. Configure a base para sincronizar a equipe.";
        document.querySelector(".settings-card.span-2 .muted").textContent = "Exporte um backup antes de trocar de navegador. Para sincronizar a equipe, configure o banco no Vercel.";
        document.querySelector("#source-maps .hint").textContent = "Google Maps requer Google Places no servidor e uma base de equipe configurada. A busca OSM funciona neste modo.";
        document.querySelector("#source-empresaqui .hint").textContent = "No modo local, importe uma exportação CSV/JSON do EmpresAqui ou use a extensão instalada para consultar CNPJ.";
        onState(readLocal());
        window.addEventListener("storage", event => { if (event.key === localKey) onState(readLocal()); });
        return;
      }
      try { session = JSON.parse(sessionStorage.getItem(sessionKey) || "null"); } catch { session = null; }
      if (session) { try { await sync(); } catch (error) { showLogin(error.message); } }
      else showLogin("Entre com a conta cadastrada pela equipe.");
      poller = setInterval(() => { if (session && !document.hidden) sync().catch(error => { if (error.status === 401 || error.status === 403) showLogin(error.message); }); }, 8000);
      document.addEventListener("visibilitychange", () => { if (!document.hidden && session) sync().catch(() => {}); });
    } catch (error) { showLogin(`Servidor indisponível: ${error.message}`); }
  }
  async function send(type, payload = {}) {
    const button = $("btnStart");
    const searching = type === "START_OSM" || type === "START_MAPS";
    if (searching) { button.disabled = true; $("runStatus").textContent = "Pesquisando a fonte e conferindo duplicatas..."; }
    try {
      if (api.localMode) return await localAction(type, payload);
      const result = await request("/api/action", { method: "POST", body: JSON.stringify({ type, payload }) });
      onState(result.state);
      return result;
    } catch (error) {
      if (searching && api.localMode && type !== "START_OSM") {
        const state = readLocal();
        state.run = { source: "Google Maps", status: "error", found: 0, scanned: 0, added: 0, matched: 0, message: error.message, finishedAt: Date.now() };
        saveLocal(state);
      }
      if (searching && !api.localMode) await sync().catch(() => {});
      if (error.status === 401 || error.status === 403) showLogin(error.message);
      throw error;
    } finally { if (searching) button.disabled = false; }
  }
  const api = { init, send, sync, members: [], actor: null, googleAvailable: false, localMode: false, isWeb: true };
  root.WebApp = api;
})(globalThis);
