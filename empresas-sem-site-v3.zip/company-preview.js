(function (root) {
  "use strict";
  const clean = value => String(value ?? "").trim();
  function webUrl(value) {
    try {
      const url = new URL(clean(value));
      return ["https:", "http:"].includes(url.protocol) && url.hostname.includes(".") ? url.href : "";
    } catch { return ""; }
  }
  function mediaList(value, limit = 8) {
    let entries = Array.isArray(value) ? value : [];
    if (!entries.length && typeof value === "string") {
      const input = value.trim();
      if (input.startsWith("[")) {
        try { const parsed = JSON.parse(input); if (Array.isArray(parsed)) entries = parsed; } catch { /* Texto livre abaixo. */ }
      }
      if (!entries.length) entries = input.split(/[\r\n;,|]+/);
    }
    return [...new Set(entries.map(webUrl).filter(Boolean))].slice(0, limit);
  }
  function instagramUrl(value) {
    const raw = clean(value);
    if (!raw) return "";
    if (/^https?:\/\//i.test(raw)) {
      const url = webUrl(raw);
      return url && /(^|\.)instagram\.com$/i.test(new URL(url).hostname) ? url : "";
    }
    const handle = raw.replace(/^@/, "");
    return /^[A-Za-z0-9._]{1,30}$/.test(handle) ? `https://www.instagram.com/${handle}/` : "";
  }
  function emailOf(value) {
    const email = clean(value);
    return /^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(email) ? email : "";
  }
  function describe(lead = {}) {
    const name = clean(lead.nome || lead.name) || "Empresa sem nome";
    const images = mediaList([lead.instagramAvatarUrl, lead.imageUrl, lead.photoUrl, ...mediaList(lead.mediaImages || lead.imageUrls || lead.images)].filter(Boolean));
    const videos = mediaList(lead.mediaVideos || lead.videoUrls || lead.videos);
    return {
      name, category: clean(lead.categoria || lead.category), address: clean(lead.endereco || [lead.cidade, lead.estado].filter(Boolean).join(", ")),
      bio: clean(lead.instagramBio || lead.bio), phone: clean(lead.whatsapp || lead.telefone),
      email: emailOf(lead.email || lead.gmail), instagram: instagramUrl(lead.instagramProfileUrl || lead.instagram),
      site: webUrl(lead.siteInformado || lead.site), source: clean(lead.source || lead.pesquisa), sourceUrl: webUrl(lead.sourceUrl),
      mediaAttribution: lead.mediaAttribution && typeof lead.mediaAttribution === "object" ? lead.mediaAttribution : {}, images, videos
    };
  }
  function node(tag, value, className) {
    const el = document.createElement(tag); if (value !== undefined) el.textContent = value;
    if (className) el.className = className; return el;
  }
  function link(label, url) {
    const a = node("a", label, "cp-link"); a.href = url; a.target = "_blank"; a.rel = "noopener noreferrer"; return a;
  }
  function render(target, lead) {
    const data = describe(lead), card = node("article", undefined, "cp-card");
    const hero = node("div", undefined, "cp-hero");
    if (data.images[0]) {
      const image = document.createElement("img"); image.src = data.images[0]; image.alt = `Imagem disponível de ${data.name}`;
      image.loading = "lazy"; image.referrerPolicy = "no-referrer";
      image.addEventListener("error", () => { image.remove(); hero.classList.add("cp-no-image"); }); hero.append(image);
    } else hero.classList.add("cp-no-image");
    const overlay = node("div", undefined, "cp-hero-copy");
    overlay.append(node("span", data.category || "Prévia do lead", "cp-kicker"), node("h4", data.name));
    if (data.address) overlay.append(node("p", data.address)); hero.append(overlay); card.append(hero);
    const body = node("div", undefined, "cp-body");
    if (data.bio) body.append(node("p", data.bio, "cp-bio"));
    const contacts = node("div", undefined, "cp-contacts");
    if (data.instagram) contacts.append(link("Instagram ↗", data.instagram));
    if (data.email) contacts.append(link(`${/@(?:gmail|googlemail)\.com$/i.test(data.email) ? "Gmail" : "E-mail"}: ${data.email}`, `mailto:${data.email}`));
    if (data.phone) contacts.append(node("span", `Telefone: ${data.phone}`, "cp-contact"));
    if (data.site) contacts.append(link("Site informado ↗", data.site));
    if (!contacts.childElementCount) contacts.append(node("span", "Nenhum contato disponível no cadastro.", "cp-empty"));
    body.append(contacts);
    const origin = node("p", undefined, "cp-origin");
    origin.append(node("span", `Dados informados por: ${data.source || "cadastro manual"}. `));
    if (data.sourceUrl) origin.append(link("Conferir origem ↗", data.sourceUrl));
    body.append(origin);
    const media = node("div", undefined, "cp-media");
    media.append(node("h5", `Imagens disponíveis (${data.images.length})`));
    const gallery = node("div", undefined, "cp-gallery");
    for (const [index, url] of data.images.entries()) {
      const item = link(`Abrir imagem ${index + 1}`, url); item.classList.add("cp-image-card");
      const image = document.createElement("img"); image.src = url; image.alt = `Imagem ${index + 1} de ${data.name}`; image.loading = "lazy"; image.referrerPolicy = "no-referrer";
      image.addEventListener("error", () => { image.remove(); item.classList.add("cp-broken"); });
      item.prepend(image);
      const evidence = data.mediaAttribution[url];
      item.append(node("small", `Fonte: ${clean(evidence?.label) || data.source || "informada pela equipe"}`, "cp-origin"));
      gallery.append(item);
    }
    if (!data.images.length) gallery.append(node("p", "Nenhuma imagem fornecida pela fonte. Adicione URLs abaixo.", "cp-empty"));
    media.append(gallery, node("h5", `Vídeos disponíveis (${data.videos.length})`));
    const videoList = node("div", undefined, "cp-videos");
    for (const [index, url] of data.videos.entries()) {
      const item = node("div", undefined, "cp-video-card");
      if (/\.(mp4|webm|ogg)(?:$|[?#])/i.test(url)) {
        const video = document.createElement("video"); video.controls = true; video.preload = "none"; video.src = url; video.setAttribute("aria-label", `Vídeo ${index + 1} de ${data.name}`); item.append(video);
      }
      item.append(link(`Abrir vídeo ${index + 1} ↗`, url));
      const evidence = data.mediaAttribution[url];
      item.append(node("small", `Fonte: ${clean(evidence?.label) || data.source || "informada pela equipe"}`, "cp-origin"));
      videoList.append(item);
    }
    if (!data.videos.length) videoList.append(node("p", "Nenhum vídeo fornecido pela fonte. Adicione URLs abaixo.", "cp-empty"));
    media.append(videoList); body.append(media, node("p", "Prévia montada somente com dados disponíveis. Confirme contatos e direitos de uso das mídias antes de compartilhar.", "cp-note"));
    card.append(body); target.replaceChildren(card); return data;
  }
  function mountEditor(target, lead, onSave, onError = () => {}) {
    const wrap = node("div", undefined, "cp-editor");
    wrap.append(node("h5", "Completar a prévia"));
    const fields = [
      ["email", "E-mail (Gmail ou outro)", lead.email || "", "input"],
      ["instagram", "Instagram", lead.instagram || "", "input"],
      ["mediaImages", "URLs de imagens (uma por linha)", mediaList(lead.mediaImages).join("\n"), "textarea"],
      ["mediaVideos", "URLs de vídeos ou Reels (uma por linha)", mediaList(lead.mediaVideos).join("\n"), "textarea"]
    ];
    const inputs = {};
    for (const [key, labelText, value, tag] of fields) {
      const label = node("label", labelText); const input = document.createElement(tag);
      if (tag === "input") input.type = key === "email" ? "email" : "text";
      else input.rows = 3;
      input.value = value; input.setAttribute("aria-label", labelText); label.append(input); wrap.append(label); inputs[key] = input;
    }
    const save = node("button", "Salvar dados da prévia", "cp-save"); save.type = "button";
    save.addEventListener("click", async () => {
      const email = clean(inputs.email.value);
      if (email && !emailOf(email)) { onError(new Error("Informe um e-mail válido.")); return; }
      const instagram = clean(inputs.instagram.value);
      if (instagram && !instagramUrl(instagram)) { onError(new Error("Informe um perfil válido do Instagram.")); return; }
      const payload = { email, instagram, mediaImages: mediaList(inputs.mediaImages.value), mediaVideos: mediaList(inputs.mediaVideos.value) };
      save.disabled = true;
      try { await onSave(payload); } catch (error) { onError(error); } finally { save.disabled = false; }
    });
    wrap.append(save); target.replaceChildren(wrap); return inputs;
  }
  function downloadHtml(lead) {
    const holder = document.createElement("div"); render(holder, lead);
    const style = `body{margin:0;padding:28px;background:#07111e;color:#f8fbff;font:16px/1.5 Arial,sans-serif}.cp-card{max-width:900px;margin:auto;border:1px solid #29445d;border-radius:18px;overflow:hidden;background:#101e30}.cp-hero{position:relative;min-height:280px;background:#153650}.cp-hero>img{width:100%;height:320px;object-fit:cover}.cp-hero-copy{position:absolute;left:0;right:0;bottom:0;padding:24px;background:linear-gradient(transparent,#05111edc)}h4{font-size:32px;margin:5px 0}h5{font-size:18px}.cp-body{padding:22px}.cp-contacts{display:flex;gap:10px;flex-wrap:wrap}.cp-link,.cp-contact{padding:7px 10px;color:#92dcff;border:1px solid #29445d;border-radius:8px}.cp-gallery{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}.cp-image-card img{width:100%;height:160px;object-fit:cover}.cp-videos{display:grid;gap:10px}.cp-video-card video{max-width:100%;max-height:300px}.cp-empty,.cp-note{color:#a9bbcf;font-size:13px}`;
    const html = `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Prévia da empresa</title><style>${style}</style></head><body>${holder.innerHTML}</body></html>`;
    const url = URL.createObjectURL(new Blob([html], { type: "text/html;charset=utf-8" }));
    const a = document.createElement("a"); a.href = url; a.download = `previa-${clean(lead.nome).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "empresa"}.html`; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }
  const api = { webUrl, mediaList, instagramUrl, emailOf, describe, render, mountEditor, downloadHtml };
  root.CompanyPreview = api;
  if (typeof module !== "undefined") module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
