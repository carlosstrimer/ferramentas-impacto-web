"use strict";
const { searchOsm, reply, fail, HttpError } = require("../lib/team-api.js");
const attempts = new Map();
const geocodes = {};
module.exports = async (req, res) => {
  if (req.method !== "POST") return reply(res, 405, { ok: false, error: "Método não permitido." });
  try {
    const body = typeof req.body === "string" ? JSON.parse(req.body) : req.body;
    if (!body || JSON.stringify(body).length > 5000) throw new HttpError(400, "Pesquisa inválida ou grande demais.");
    const ip = String(req.headers["x-forwarded-for"] || req.socket?.remoteAddress || "local").split(",")[0].trim();
    const now = Date.now();
    const recent = (attempts.get(ip) || []).filter(time => now - time < 60000);
    if (recent.length >= 3) throw new HttpError(429, "Muitas pesquisas neste minuto. Aguarde e tente novamente.");
    attempts.set(ip, [...recent, now]);
    if (attempts.size > 2000) for (const [key, times] of attempts) if (times.every(time => now - time >= 60000)) attempts.delete(key);
    if (Number(body.limit) > 20 || Number(body.radius) > 5000) throw new HttpError(400, "No modo local, use até 20 resultados e raio de até 5.000 m.");
    const params = { ...body, limit: Number(body.limit) || 20, radius: Number(body.radius) || 3000 };
    const result = await searchOsm(params, geocodes);
    geocodes[result.cacheKey] = result.center;
    reply(res, 200, { ok: true, rows: result.rows, found: result.found, scanned: result.rows.length, attribution: "© OpenStreetMap contributors (ODbL)" });
  } catch (error) { fail(res, error); }
};
