"use strict";
const { memberFor, action, reply, fail } = require("../lib/team-api.js");
module.exports = async (req, res) => {
  if (req.method !== "POST") return reply(res, 405, { ok: false, error: "Método não permitido." });
  try {
    const actor = await memberFor(req);
    const body = typeof req.body === "string" ? JSON.parse(req.body) : req.body;
    if (!body || typeof body.type !== "string" || JSON.stringify(body).length > 2_000_000) return reply(res, 400, { ok: false, error: "Requisição inválida ou grande demais." });
    const response = await action(body.type, body.payload || {}, actor);
    reply(res, 200, { ok: true, state: response.state, ...(response.result || {}) });
  } catch (error) { fail(res, error); }
};
