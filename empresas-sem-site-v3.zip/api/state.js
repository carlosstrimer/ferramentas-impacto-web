"use strict";
const { memberFor, members, stateRow, reply, fail } = require("../lib/team-api.js");
module.exports = async (req, res) => {
  if (req.method !== "GET") return reply(res, 405, { ok: false, error: "Método não permitido." });
  try { const actor = await memberFor(req); const [current, team] = await Promise.all([stateRow(), members()]); reply(res, 200, { ok: true, state: current.data, members: team, actor }); }
  catch (error) { fail(res, error); }
};
