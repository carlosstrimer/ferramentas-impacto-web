"use strict";
const { reply } = require("../lib/team-api.js");
module.exports = async (req, res) => {
  if (req.method !== "GET") return reply(res, 405, { ok: false, error: "Método não permitido." });
  reply(res, 200, { ok: true, configured: Boolean(process.env.SUPABASE_URL && process.env.SUPABASE_ANON_KEY && process.env.SUPABASE_SERVICE_ROLE_KEY), supabaseUrl: process.env.SUPABASE_URL || "", anonKey: process.env.SUPABASE_ANON_KEY || "", googleAvailable: Boolean(process.env.GOOGLE_PLACES_API_KEY) });
};
