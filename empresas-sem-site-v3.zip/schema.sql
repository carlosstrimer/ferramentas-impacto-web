-- Execute uma vez no SQL Editor do Supabase. A API usa a service role somente no servidor.
create table if not exists public.team_members (
  user_id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  display_name text not null,
  role text not null default 'member' check (role in ('admin', 'member')),
  created_at timestamptz not null default now()
);
create table if not exists public.workspace_state (
  id text primary key,
  version bigint not null default 0,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
insert into public.workspace_state (id, data)
values ('main', '{"leads":[],"logs":[],"run":null}'::jsonb)
on conflict (id) do nothing;
alter table public.team_members enable row level security;
alter table public.workspace_state enable row level security;
revoke all on public.team_members from anon, authenticated;
revoke all on public.workspace_state from anon, authenticated;
-- Depois de criar cada usuário em Authentication, inclua-o na equipe:
-- insert into public.team_members (user_id, email, display_name, role)
-- select id, email, 'Nome da pessoa', 'member' from auth.users where email = 'pessoa@empresa.com';
